const db = require('../config/database');

module.exports.default = (req, res) => {
    res.render('index');
};